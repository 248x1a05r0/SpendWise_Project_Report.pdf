import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:spendwise/main.dart';
import 'package:spendwise/providers/expense_provider.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('SpendWise app shows the main navigation destinations',
      (tester) async {
    await tester.pumpWidget(
      ChangeNotifierProvider(
        create: (_) => ExpenseProvider(),
        child: const SpendWiseApp(),
      ),
    );

    expect(find.text('Home'), findsOneWidget);
    expect(find.text('Expenses'), findsOneWidget);
    expect(find.text('Add'), findsOneWidget);
    expect(find.text('Summary'), findsOneWidget);
  });
}
