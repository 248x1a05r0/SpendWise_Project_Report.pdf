import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../providers/expense_provider.dart';
import '../widgets/expense_tile.dart';

class SummaryScreen extends StatelessWidget {
  const SummaryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ExpenseProvider>();
    final theme = Theme.of(context);
    final totals = provider.totalsByCategory.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final total = provider.totalSpent;

    return Scaffold(
      appBar: AppBar(title: const Text('Spending summary')),
      body: provider.status == ExpenseLoadStatus.loading
          ? const Center(child: CircularProgressIndicator())
          : provider.status == ExpenseLoadStatus.error
              ? Center(
                  child: FilledButton.icon(
                    onPressed: provider.loadExpenses,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Retry loading summary'),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(22),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Total spending',
                                style: theme.textTheme.titleMedium),
                            const SizedBox(height: 8),
                            Text(
                              '₹${NumberFormat('#,##,##0.00').format(total)}',
                              style: theme.textTheme.headlineMedium?.copyWith(
                                fontWeight: FontWeight.w800,
                                color: theme.colorScheme.primary,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text('${provider.expenses.length} transactions recorded',
                                style: theme.textTheme.bodySmall),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 22),
                    Text('By category',
                        style: theme.textTheme.titleLarge
                            ?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 12),
                    if (totals.isEmpty)
                      const Card(
                        child: Padding(
                          padding: EdgeInsets.all(24),
                          child: Center(
                            child: Text(
                              'No data to summarize yet. Add your first expense.',
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      )
                    else
                      ...totals.map((entry) {
                        final ratio = total == 0 ? 0.0 : entry.value / total;
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    CircleAvatar(
                                      backgroundColor:
                                          theme.colorScheme.primaryContainer,
                                      foregroundColor: theme.colorScheme.primary,
                                      child: Icon(categoryIcon(entry.key)),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Text(entry.key,
                                          style: theme.textTheme.titleSmall
                                              ?.copyWith(fontWeight: FontWeight.w700)),
                                    ),
                                    Text(
                                      '₹${entry.value.toStringAsFixed(2)}',
                                      style: theme.textTheme.titleSmall
                                          ?.copyWith(fontWeight: FontWeight.w800),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                LinearProgressIndicator(
                                  value: ratio.clamp(0.0, 1.0),
                                  minHeight: 8,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                const SizedBox(height: 5),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: Text('${(ratio * 100).toStringAsFixed(1)}%',
                                      style: theme.textTheme.bodySmall),
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                  ],
                ),
    );
  }
}
