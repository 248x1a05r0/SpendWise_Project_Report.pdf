import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/expense.dart';
import '../providers/expense_provider.dart';

class AddExpenseScreen extends StatefulWidget {
  const AddExpenseScreen({super.key});

  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _noteController = TextEditingController();
  final _categories = const [
    'Food', 'Travel', 'Shopping', 'Bills', 'Health', 'Education', 'Other'
  ];

  String? _category;
  DateTime? _date = DateTime.now();
  bool _saving = false;

  @override
  void dispose() {
    _amountController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _date ?? now,
      firstDate: DateTime(2000),
      lastDate: DateTime(now.year + 5),
    );
    if (picked != null && mounted) setState(() => _date = picked);
  }

  Future<void> _save() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;
    if (_category == null || _date == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a category and date.')),
      );
      return;
    }

    setState(() => _saving = true);
    try {
      final expense = Expense(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        amount: double.parse(_amountController.text.trim()),
        category: _category!,
        date: _date!,
        note: _noteController.text.trim(),
      );
      await context.read<ExpenseProvider>().addExpense(expense);
      if (!mounted) return;
      _amountController.clear();
      _noteController.clear();
      setState(() {
        _category = null;
        _date = DateTime.now();
        _saving = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Expense saved successfully.')),
      );
    } catch (_) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Could not save expense. Please try again.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Add expense')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          children: [
            Text('Record a transaction',
                style: theme.textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('Enter the details below to keep your spending up to date.',
                style: theme.textTheme.bodyMedium
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            const SizedBox(height: 22),
            TextFormField(
              controller: _amountController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Amount (₹)',
                prefixIcon: Icon(Icons.currency_rupee_rounded),
                hintText: 'e.g. 250.00',
              ),
              validator: (value) {
                final amount = double.tryParse((value ?? '').trim());
                if (value == null || value.trim().isEmpty) {
                  return 'Please enter an amount.';
                }
                if (amount == null || !amount.isFinite) {
                  return 'Enter a valid number.';
                }
                if (amount <= 0) return 'Amount must be greater than zero.';
                if (amount > 100000000) return 'Amount is too large.';
                return null;
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _category,
              decoration: const InputDecoration(
                labelText: 'Category',
                prefixIcon: Icon(Icons.category_outlined),
              ),
              items: _categories
                  .map((category) => DropdownMenuItem(
                        value: category,
                        child: Text(category),
                      ))
                  .toList(),
              onChanged: (value) => setState(() => _category = value),
              validator: (value) =>
                  value == null ? 'Please select a category.' : null,
            ),
            const SizedBox(height: 16),
            FormField<DateTime>(
              initialValue: _date,
              validator: (value) =>
                  value == null ? 'Please select a date.' : null,
              builder: (field) => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  OutlinedButton.icon(
                    onPressed: () async {
                      await _pickDate();
                      field.didChange(_date);
                    },
                    icon: const Icon(Icons.calendar_month_outlined),
                    label: Text(_date == null
                        ? 'Choose date'
                        : '${_date!.day.toString().padLeft(2, '0')}/${_date!.month.toString().padLeft(2, '0')}/${_date!.year}'),
                  ),
                  if (field.errorText != null)
                    Padding(
                      padding: const EdgeInsets.only(left: 12, top: 5),
                      child: Text(field.errorText!,
                          style: TextStyle(
                              color: theme.colorScheme.error, fontSize: 12)),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _noteController,
              maxLength: 120,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Note',
                hintText: 'What was this expense for?',
                alignLabelWithHint: true,
                prefixIcon: Icon(Icons.notes_rounded),
              ),
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Please enter a short note.';
                }
                if (value.trim().length < 2) {
                  return 'Note must contain at least 2 characters.';
                }
                if (value.trim().length > 120) {
                  return 'Note cannot exceed 120 characters.';
                }
                return null;
              },
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.save_rounded),
                label: Text(_saving ? 'Saving...' : 'Save expense'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
