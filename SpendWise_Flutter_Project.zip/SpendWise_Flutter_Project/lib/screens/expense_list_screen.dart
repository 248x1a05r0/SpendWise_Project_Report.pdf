import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/expense_provider.dart';
import '../widgets/expense_tile.dart';
import 'expense_detail_screen.dart';

class ExpenseListScreen extends StatefulWidget {
  const ExpenseListScreen({super.key});

  @override
  State<ExpenseListScreen> createState() => _ExpenseListScreenState();
}

class _ExpenseListScreenState extends State<ExpenseListScreen> {
  String _filter = 'All';

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ExpenseProvider>();
    final categories = ['All', ...provider.totalsByCategory.keys.toList()..sort()];
    final visible = provider.expenses
        .where((expense) => _filter == 'All' || expense.category == _filter)
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('All expenses')),
      body: provider.status == ExpenseLoadStatus.loading
          ? const Center(child: CircularProgressIndicator())
          : provider.status == ExpenseLoadStatus.error
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(provider.errorMessage ?? 'Unable to load expenses.'),
                      const SizedBox(height: 10),
                      FilledButton(
                        onPressed: provider.loadExpenses,
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: provider.loadExpenses,
                  child: ListView(
                    padding: const EdgeInsets.all(20),
                    children: [
                      if (categories.length > 1)
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: categories.map((category) {
                              final selected = _filter == category;
                              return Padding(
                                padding: const EdgeInsets.only(right: 8),
                                child: ChoiceChip(
                                  label: Text(category),
                                  selected: selected,
                                  onSelected: (_) =>
                                      setState(() => _filter = category),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      const SizedBox(height: 14),
                      if (visible.isEmpty)
                        const Padding(
                          padding: EdgeInsets.only(top: 90),
                          child: Column(
                            children: [
                              Icon(Icons.receipt_long_outlined, size: 48),
                              SizedBox(height: 12),
                              Text('No expenses found.'),
                              Text('Add an expense to see it here.'),
                            ],
                          ),
                        )
                      else
                        ...visible.map((expense) => ExpenseTile(
                              expense: expense,
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      ExpenseDetailScreen(expense: expense),
                                ),
                              ),
                            )),
                    ],
                  ),
                ),
    );
  }
}
