import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../providers/expense_provider.dart';
import '../widgets/expense_tile.dart';
import 'expense_detail_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ExpenseProvider>();
    final theme = Theme.of(context);
    final recent = provider.expenses.take(3).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('SpendWise',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: CircleAvatar(
              backgroundColor: theme.colorScheme.primaryContainer,
              child: Icon(Icons.person_outline, color: theme.colorScheme.primary),
            ),
          ),
        ],
      ),
      body: provider.status == ExpenseLoadStatus.loading
          ? const Center(child: CircularProgressIndicator())
          : provider.status == ExpenseLoadStatus.error
              ? _ErrorState(onRetry: provider.loadExpenses,
                  message: provider.errorMessage ?? 'Something went wrong.')
              : RefreshIndicator(
                  onRefresh: provider.loadExpenses,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                    children: [
                      Text('Good spending starts here',
                          style: theme.textTheme.titleMedium
                              ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                      const SizedBox(height: 16),
                      _TotalCard(total: provider.totalSpent),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Recent activity',
                              style: theme.textTheme.titleLarge
                                  ?.copyWith(fontWeight: FontWeight.w800)),
                          Text('${provider.expenses.length} records',
                              style: theme.textTheme.bodySmall),
                        ],
                      ),
                      const SizedBox(height: 12),
                      if (recent.isEmpty)
                        const _EmptyState()
                      else
                        ...recent.map((expense) => ExpenseTile(
                              expense: expense,
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      ExpenseDetailScreen(expense: expense),
                                ),
                              ),
                            )),
                      const SizedBox(height: 12),
                      Text('Tip: Add expenses regularly to understand your habits.',
                          style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
    );
  }
}

class _TotalCard extends StatelessWidget {
  const _TotalCard({required this.total});
  final double total;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      color: theme.colorScheme.primary,
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Total recorded spending',
                style: theme.textTheme.titleSmall
                    ?.copyWith(color: theme.colorScheme.onPrimary.withValues(alpha: .85))),
            const SizedBox(height: 10),
            Text('₹${NumberFormat('#,##,##0.00').format(total)}',
                style: theme.textTheme.headlineMedium?.copyWith(
                  color: theme.colorScheme.onPrimary,
                  fontWeight: FontWeight.w800,
                )),
            const SizedBox(height: 14),
            Row(
              children: [
                Icon(Icons.insights_rounded,
                    color: theme.colorScheme.onPrimary, size: 18),
                const SizedBox(width: 7),
                Text('Track it. Understand it. Improve it.',
                    style: theme.textTheme.bodySmall
                        ?.copyWith(color: theme.colorScheme.onPrimary)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Icon(Icons.account_balance_wallet_outlined,
                size: 42, color: theme.colorScheme.primary),
            const SizedBox(height: 10),
            Text('No expenses yet',
                style: theme.textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 5),
            const Text('Your transactions will appear here after you add one.',
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.onRetry, required this.message});
  final VoidCallback onRetry;
  final String message;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off_rounded, size: 42),
              const SizedBox(height: 12),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
}
