import 'package:flutter/foundation.dart';

import '../models/expense.dart';
import '../services/expense_storage.dart';

enum ExpenseLoadStatus { loading, loaded, error }

class ExpenseProvider extends ChangeNotifier {
  ExpenseProvider({ExpenseStorage? storage})
      : _storage = storage ?? ExpenseStorage();

  final ExpenseStorage _storage;
  List<Expense> _expenses = [];
  ExpenseLoadStatus _status = ExpenseLoadStatus.loading;
  String? _errorMessage;

  List<Expense> get expenses => List.unmodifiable(_expenses);
  ExpenseLoadStatus get status => _status;
  String? get errorMessage => _errorMessage;

  double get totalSpent =>
      _expenses.fold(0, (total, expense) => total + expense.amount);

  Map<String, double> get totalsByCategory {
    final totals = <String, double>{};
    for (final expense in _expenses) {
      totals.update(
        expense.category,
        (value) => value + expense.amount,
        ifAbsent: () => expense.amount,
      );
    }
    return totals;
  }

  Future<void> loadExpenses() async {
    _status = ExpenseLoadStatus.loading;
    _errorMessage = null;
    notifyListeners();
    try {
      _expenses = await _storage.readExpenses();
      _expenses.sort((a, b) => b.date.compareTo(a.date));
      _status = ExpenseLoadStatus.loaded;
    } catch (_) {
      _status = ExpenseLoadStatus.error;
      _errorMessage = 'Unable to load saved expenses. Please try again.';
    }
    notifyListeners();
  }

  Future<void> addExpense(Expense expense) async {
    final updated = [expense, ..._expenses]
      ..sort((a, b) => b.date.compareTo(a.date));
    await _storage.writeExpenses(updated);
    _expenses = updated;
    _status = ExpenseLoadStatus.loaded;
    notifyListeners();
  }

  Future<void> deleteExpense(String id) async {
    final updated = _expenses.where((expense) => expense.id != id).toList();
    await _storage.writeExpenses(updated);
    _expenses = updated;
    notifyListeners();
  }
}
