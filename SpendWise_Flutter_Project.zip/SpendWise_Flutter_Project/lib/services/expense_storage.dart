import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/expense.dart';

class ExpenseStorage {
  static const _storageKey = 'spendwise_expenses_v1';

  Future<List<Expense>> readExpenses() async {
    final preferences = await SharedPreferences.getInstance();
    final raw = preferences.getString(_storageKey);
    if (raw == null || raw.isEmpty) return [];

    final decoded = jsonDecode(raw);
    if (decoded is! List) {
      throw const FormatException('Saved expense data is not a list.');
    }

    return decoded
        .map((item) => Expense.fromJson(
              Map<String, dynamic>.from(item as Map),
            ))
        .toList();
  }

  Future<void> writeExpenses(List<Expense> expenses) async {
    final preferences = await SharedPreferences.getInstance();
    final encoded = jsonEncode(expenses.map((e) => e.toJson()).toList());
    final saved = await preferences.setString(_storageKey, encoded);
    if (!saved) {
      throw Exception('The device could not save your expenses.');
    }
  }
}
