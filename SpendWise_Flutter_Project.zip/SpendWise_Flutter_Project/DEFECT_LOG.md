# SpendWise – Defect Log

Record actual defects found during testing. Do not mark a defect fixed until the fix has been tested.

| ID | Defect / observation | Steps to reproduce | Expected result | Status | Fix / verification |
|---|---|---|---|---|---|
| D-001 | Pending execution on target devices | Install release APK and launch | App opens without crash | Not yet tested | Complete after physical-device test |
| D-002 | Pending form validation test | Submit form with blank amount | Clear amount validation message appears | Not yet tested | Complete after test |
| D-003 | Pending persistence test | Add expense, close and reopen app | Expense remains available | Not yet tested | Complete after test |
| D-004 | Pending orientation test | Rotate device while viewing each screen | Layout remains usable | Not yet tested | Complete after test |

Add a new row for every defect discovered. Include app version/device details when useful.
