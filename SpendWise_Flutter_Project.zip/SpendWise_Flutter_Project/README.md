# SpendWise – Personal Expense Tracker

**Topic:** Expense Tracker  
**Platform:** Android  
**Framework:** Flutter 3.35+  
**Language:** Dart (null safety)

## 1. Description

SpendWise is a modern personal expense tracking application. Users can record expenses with an amount, category, date and note; browse transactions; inspect transaction details; and review category-wise spending totals. Records are stored locally on the device and remain available after the application is restarted.

## 2. Features

- Dashboard with total recorded spending and recent activity.
- Expense list with category filtering.
- Expense detail screen with transaction information.
- Validated add-expense form.
- Spending summary with category totals and percentage bars.
- Local persistence using SharedPreferences.
- Shared application state using Provider and ChangeNotifier.
- Loading, error/retry and empty states.
- Delete transaction action with confirmation.
- Material 3 theme generated from one seed colour.

## 3. Screenshots

Add at least three genuine screenshots from the running Android application before submission:

| File | Screen to capture |
|---|---|
| `screenshots/01_dashboard.png` | Dashboard with at least two saved expenses |
| `screenshots/02_expense_list.png` | Expense list |
| `screenshots/03_add_expense.png` | Add expense form |
| `screenshots/04_summary.png` | Category summary (recommended) |

Create the `screenshots` folder and place the actual screenshots there. Do not submit placeholder images.

## 4. Data source

The application uses user-created expense records saved locally through the `shared_preferences` package as JSON. No public API key or internet connection is required for normal use.

## 5. Requirements

- Flutter stable 3.35 or newer
- Dart SDK compatible with the Flutter installation
- Android Studio with Flutter and Dart plugins
- JDK 17
- Android SDK / emulator or physical Android phone

## 6. Run the application

1. Install Flutter and Android Studio.
2. Clone the repository.
3. Open a terminal in the project directory.
4. Generate the Android platform folder for this starter source project:

```bash
flutter create --platforms=android .
```

5. Fetch packages and verify the project:

```bash
flutter doctor
flutter pub get
flutter analyze
flutter test
flutter run
```

## 7. Build a release APK

Connect an Android phone with USB debugging enabled, or use an emulator for testing. Build the release APK:

```bash
flutter build apk --release
```

APK output:

```text
build/app/outputs/flutter-apk/app-release.apk
```

Install on a connected device:

```bash
flutter install --release
```

Test the APK on a physical Android phone before submission.

## 8. Project structure

```text
lib/
  main.dart
  models/
    expense.dart
  providers/
    expense_provider.dart
  services/
    expense_storage.dart
  screens/
    app_shell.dart
    dashboard_screen.dart
    expense_list_screen.dart
    add_expense_screen.dart
    expense_detail_screen.dart
    summary_screen.dart
  widgets/
    expense_tile.dart
test/
  widget_test.dart
```

## 9. Team members and contributions

Replace the placeholders with the actual names of all three students.

| Member | Name | Contribution |
|---|---|---|
| Student 1 | [Enter name] | Dashboard and expense list screens |
| Student 2 | [Enter name] | Add expense form and expense detail screen |
| Student 3 | [Enter name] | Provider, local storage, summary screen and widget test |

Every member must make regular commits using their own Git identity and be able to explain their contribution.

## 10. GitHub workflow

```bash
git init
git add .
git commit -m "Initial SpendWise Flutter project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/spendwise.git
git push -u origin main
```

Use small, meaningful commits throughout development. Do not wait until the end to upload the entire project.

## 11. Testing checklist

- [ ] Add a valid expense.
- [ ] Reject blank amount.
- [ ] Reject non-numeric amount.
- [ ] Reject zero and negative amount.
- [ ] Reject missing category.
- [ ] Reject missing date.
- [ ] Reject blank or too-short note.
- [ ] Verify category filtering.
- [ ] Open a transaction detail screen.
- [ ] Delete a transaction after confirmation.
- [ ] Verify totals and category percentages.
- [ ] Restart the app and verify records persist.
- [ ] Test with no saved expenses.
- [ ] Test with long note text.
- [ ] Test rapid repeated taps.
- [ ] Rotate the phone and check the layout.
- [ ] Run `flutter analyze` and `flutter test`.
- [ ] Install and test the release APK on a physical phone.

## 12. Five-minute demonstration plan

- **0:00–0:30:** Introduce SpendWise, its target users and the problem it solves.
- **0:30–3:30:** Demonstrate dashboard, expense list, detail, valid expense creation, rejected invalid form entry, empty state (if available in a clean test install), and category summary.
- **3:30–4:30:** Explain one technical challenge, such as preserving records locally and sharing state across screens. All members speak.
- **4:30–5:00:** Show GitHub commit history and the release APK.

## 13. Security and release notes

This app stores expense records locally on the device. SharedPreferences is suitable for this learning project, but it is not encrypted financial storage. Do not commit personal expense data, signing keys, passwords or other secrets to GitHub.
