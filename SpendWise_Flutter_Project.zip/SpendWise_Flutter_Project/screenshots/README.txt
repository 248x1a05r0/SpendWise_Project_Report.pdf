Place at least three genuine screenshots captured from the running app in this folder before submission.
